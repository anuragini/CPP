#include <iostream>

int main()
{
	std::cout << "Hello World,Hello CSCI 1300!" << std::endl;
}